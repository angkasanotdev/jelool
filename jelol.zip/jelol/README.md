```
apt update && apt upgrade -y
```
```
apt install python3 python3-pip git unzip -y
```
```
apt install npm
```
```
npm install -g uglify-js
```
```
wget https://github.com/angkasanotdev/jelool/raw/main/jelool.zip
```
```
unzip jelool.zip
```
```
cd jelool
```
```
pip install -r requirements.txt
```
```
cp sample.env .env
```
```
nano .env
```
```
CTRL + C
```
```
bash start.sh
```
```
apt install screen -y
```
```
screen -S ubotangkasa
```
```
cd ~/ubotangkasa 
UVLOOP_NO_EXTENSIONS=1 bash start.sh
```
```
CTRL + A LALU D
```