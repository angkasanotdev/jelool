__MODULE__ = "ᴀꜰᴋ"
__HELP__ = """
<blockquote><b>Bantuan untuk Afk

perintah : <code>{0}afk</code> [alasan]
    untuk mengaktifkan afk

perintah : unafk
    menonaktifkan afk</b></blockquote>
"""
