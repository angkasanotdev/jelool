import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "200"))

DEVS = list(map(int, os.getenv("DEVS", "6736986837").split()))

API_ID = int(os.getenv("API_ID", "20605735"))

API_HASH = os.getenv("API_HASH", "5bcd7f6a093c804d38263259381a4ef0")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8532560250:AAFG0guSvFGab2Y1NBRiRimAooeozDGWE6c")

OWNER_ID = int(os.getenv("OWNER_ID", "6736986837"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002312835928").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://databasepunyaangkasa_db_user:L2U3lpSTjI2RrpjY@cluster0.0ti6vzz.mongodb.net/?appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "--1003282036854"))
